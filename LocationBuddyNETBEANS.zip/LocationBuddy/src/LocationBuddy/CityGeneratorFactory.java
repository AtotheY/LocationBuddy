/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package LocationBuddy;
/**
 * Created by neethan on 2015-12-02.
 */

//This class is the factory class which returns the RandomCity class back.
public class CityGeneratorFactory {
    public CityGenerator generateCity() throws Exception{

        //return the created random city.
        return new RandomCity();
    }
}

