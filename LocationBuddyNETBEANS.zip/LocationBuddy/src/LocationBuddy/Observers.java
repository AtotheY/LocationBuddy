/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package LocationBuddy;

/**
 * Created by Serban Badea on 12/4/2015.
 */
public interface Observers {
    public void update(double windSpeed, long humidity, double pressure);
    //Observer interface, takes in the values we are observing, serves to de-couple
}
